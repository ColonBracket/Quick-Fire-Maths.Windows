﻿Public Class Form1
    Dim varGameStart As Integer
    Dim varQuizType As Integer
    Dim varQuizTypeRnd As Integer
    Dim varRandomNumber As New Random
    Dim varQuesAnswer As Double
    Dim varRandAnswerButton As Integer
    Dim varQuesAnsweredTotal As Integer
    Dim varQuesAnsweredCorrect As Integer

    Public Function funcInitialize()
        varGameStart = 0
        varQuizType = 0
        varQuizTypeRnd = 0
        varQuesAnswer = 0
        varRandAnswerButton = 0
        varQuesAnsweredTotal = 0
        varQuesAnsweredCorrect = 0
        btnAnswerA.Enabled = False
        btnAnswerB.Enabled = False
        btnAnswerC.Enabled = False
        btnAnswerD.Enabled = False
        lblScorePercent.Text = "100%"
        lblTimer.Text = "30"
        timerTimer.Stop()
        lblQuesRemain.Text = "25"
        lblQuesNumber1.Text = "0"
        lblQuesNumber2.Text = "0"
        lblQuizTypeSymbol.Text = "*"
        btnAnswerA.Text = "A"
        btnAnswerB.Text = "B"
        btnAnswerC.Text = "C"
        btnAnswerD.Text = "D"
    End Function

    Public Function funcQuesGeneratorAdd()
        lblQuesNumber1.Text = varRandomNumber.Next(5, 50)
        lblQuesNumber2.Text = varRandomNumber.Next(5, 50)
        lblQuizTypeSymbol.Text = "+"
        varQuesAnswer = Val(lblQuesNumber1.Text) + Val(lblQuesNumber2.Text)
        varQuesAnswer = Math.Round(varQuesAnswer, 1)
        varRandAnswerButton = varRandomNumber.Next(1, 4)
        Select Case varRandAnswerButton
            Case 1
                btnAnswerA.Text = varQuesAnswer
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
            Case 2
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerB.Text = varQuesAnswer
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
            Case 3
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerC.Text = varQuesAnswer
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
            Case 4
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerD.Text = varQuesAnswer
        End Select
    End Function

    Public Function funcQuesGeneratorSub()
        lblQuesNumber1.Text = varRandomNumber.Next(5, 50)
        lblQuesNumber2.Text = varRandomNumber.Next(5, 50)
        lblQuizTypeSymbol.Text = "-"
        varQuesAnswer = Val(lblQuesNumber1.Text) - Val(lblQuesNumber2.Text)
        varQuesAnswer = Math.Round(varQuesAnswer, 1)
        varRandAnswerButton = varRandomNumber.Next(1, 4)
        Select Case varRandAnswerButton
            Case 1
                btnAnswerA.Text = varQuesAnswer
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
            Case 2
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerB.Text = varQuesAnswer
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
            Case 3
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerC.Text = varQuesAnswer
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
            Case 4
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-10, 10)
                btnAnswerD.Text = varQuesAnswer
        End Select
    End Function

    Public Function funcQuesGeneratorMul()
        lblQuesNumber1.Text = varRandomNumber.Next(5, 50)
        lblQuesNumber2.Text = varRandomNumber.Next(5, 50)
        lblQuizTypeSymbol.Text = "*"
        varQuesAnswer = Val(lblQuesNumber1.Text) * Val(lblQuesNumber2.Text)
        varQuesAnswer = Math.Round(varQuesAnswer, 1)
        varRandAnswerButton = varRandomNumber.Next(1, 4)
        Select Case varRandAnswerButton
            Case 1
                btnAnswerA.Text = varQuesAnswer
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
            Case 2
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerB.Text = varQuesAnswer
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
            Case 3
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerC.Text = varQuesAnswer
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
            Case 4
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-50, 50)
                btnAnswerD.Text = varQuesAnswer
        End Select
    End Function

    Public Function funcQuesGeneratorDiv()
        lblQuesNumber1.Text = varRandomNumber.Next(5, 50)
        lblQuesNumber2.Text = varRandomNumber.Next(5, 50)
        lblQuizTypeSymbol.Text = "/"
        varQuesAnswer = Val(lblQuesNumber1.Text) / Val(lblQuesNumber2.Text)
        varQuesAnswer = Math.Round(varQuesAnswer, 1)
        varRandAnswerButton = varRandomNumber.Next(1, 4)
        Select Case varRandAnswerButton
            Case 1
                btnAnswerA.Text = varQuesAnswer
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
            Case 2
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerB.Text = varQuesAnswer
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
            Case 3
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerC.Text = varQuesAnswer
                btnAnswerD.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
            Case 4
                btnAnswerA.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerB.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerC.Text = varQuesAnswer + varRandomNumber.Next(-100, 100)
                btnAnswerD.Text = varQuesAnswer
        End Select
    End Function

    Public Function funcQuesGeneratorRnd()
        varQuizTypeRnd = varRandomNumber.Next(1, 4)
        Select Case varQuizTypeRnd
            Case 1
                funcQuesGeneratorAdd()
            Case 2
                funcQuesGeneratorSub()
            Case 3
                funcQuesGeneratorMul()
            Case 4
                funcQuesGeneratorDiv()
        End Select
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        timerTimer.Stop()
        MsgBox("Welcome to Quick Fire Maths (for Windows)!" & vbCrLf & vbCrLf & "Select your quiz type! You have 30 seconds to answer all questions.")
        btnAnswerA.Enabled = False
        btnAnswerB.Enabled = False
        btnAnswerC.Enabled = False
        btnAnswerD.Enabled = False
    End Sub

    Private Sub timerTimer_Tick(sender As Object, e As EventArgs) Handles timerTimer.Tick
        lblTimer.Text = Val(lblTimer.Text) - 1
        If Val(lblTimer.Text) = 0 Then
            If varQuesAnsweredTotal = 0 Then
                lblScorePercent.Text = "0%"
            End If
            timerTimer.Stop()
            MsgBox("The quiz is over! Good game!" & vbCrLf & vbCrLf & "You have run out of time... You got " & lblScorePercent.Text & "! ")
            funcInitialize()
        End If
    End Sub

    Private Sub btnHelp_Click(sender As Object, e As EventArgs) Handles btnHelp.Click
        MsgBox("Quick Fire Maths (for Windows) by Delta Developers Team." & vbCrLf & "(C) 2016 Delta Developers Team. All rights reserved." & vbCrLf & vbCrLf & "1. Select your quiz type from the top of the window and start playing. You have 30 seconds to answer all questions." & vbCrLf & vbCrLf & "2. Answer questions by selecting your answer from the bottom of the window. Your score percentage will change every time you answer a question correctly / incorrectly." & vbCrLf & vbCrLf & "3. When time runs out, the quiz ends. You can restart by selecting a new quiz type." & vbCrLf & vbCrLf & "4. If you wish to change your quiz type mid-game, you can by selecting a new quiz type from the top of the window. Your score and timer will be reset." & vbCrLf & vbCrLf & "5. Enjoy playing the quiz!" & vbCrLf & vbCrLf & "Note that the OS X (Mac) version of Quick Fire Maths performs the best and is the most original version of the game. The Windows version is developed for those who wish to run the game on Windows machines.")
    End Sub

    Private Sub btnQuizTypeAdd_Click(sender As Object, e As EventArgs) Handles btnQuizTypeAdd.Click
        If varGameStart = 0 Then
            varGameStart = 1
            varQuizType = 1
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorAdd()
        ElseIf varGameStart = 1 Then
            MsgBox("You have chosen to restart your quiz with a new set of questions. Your score and time will be reset.")
            funcInitialize()
            varQuizType = 1
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorAdd()
        End If
    End Sub

    Private Sub btnQuizTypeSub_Click(sender As Object, e As EventArgs) Handles btnQuizTypeSub.Click
        If varGameStart = 0 Then
            varGameStart = 1
            varQuizType = 2
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorSub()
        ElseIf varGameStart = 1 Then
            MsgBox("You have chosen to restart your quiz with a new set of questions. Your score and time will be reset.")
            funcInitialize()
            varQuizType = 2
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorSub()
        End If
    End Sub

    Private Sub btnQuizTypeMul_Click(sender As Object, e As EventArgs) Handles btnQuizTypeMul.Click
        If varGameStart = 0 Then
            varGameStart = 1
            varQuizType = 3
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorMul()
        ElseIf varGameStart = 1 Then
            MsgBox("You have chosen to restart your quiz with a new set of questions. Your score and time will be reset.")
            funcInitialize()
            varQuizType = 3
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorMul()
        End If
    End Sub

    Private Sub btnQuizTypeDiv_Click(sender As Object, e As EventArgs) Handles btnQuizTypeDiv.Click
        If varGameStart = 0 Then
            varGameStart = 1
            varQuizType = 4
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorDiv()
        ElseIf varGameStart = 1 Then
            MsgBox("You have chosen to restart your quiz with a new set of questions. Your score and time will be reset.")
            funcInitialize()
            varQuizType = 4
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorDiv()
        End If
    End Sub

    Private Sub btnQuizTypeRnd_Click(sender As Object, e As EventArgs) Handles btnQuizTypeRnd.Click
        If varGameStart = 0 Then
            varGameStart = 1
            varQuizType = 5
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorRnd()
        ElseIf varGameStart = 1 Then
            MsgBox("You have chosen to restart your quiz with a new set of questions. Your score and time will be reset.")
            funcInitialize()
            varQuizType = 3
            lblTimer.Text = "30"
            timerTimer.Start()
            lblQuesRemain.Text = "25"
            btnAnswerA.Enabled = True
            btnAnswerB.Enabled = True
            btnAnswerC.Enabled = True
            btnAnswerD.Enabled = True
            funcQuesGeneratorRnd()
        End If
    End Sub

    Private Sub btnAnswerA_Click(sender As Object, e As EventArgs) Handles btnAnswerA.Click
        If Val(lblQuesRemain.Text) <= 0 Then
            timerTimer.Stop()
            If varQuesAnsweredTotal = 0 Then
                lblScorePercent.Text = "0%"
            End If
            MsgBox("The quiz is over! Good game!" & vbCrLf & vbCrLf & "Well done - you finished all the questions in time! You got " & lblScorePercent.Text & "! ")
            funcInitialize()
        ElseIf btnAnswerA.Text = varQuesAnswer Then
            varQuesAnsweredCorrect = varQuesAnsweredCorrect + 1
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
            End Select
            lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
        Else
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
            End Select
            lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
        End If
    End Sub

    Private Sub btnAnswerB_Click(sender As Object, e As EventArgs) Handles btnAnswerB.Click
        If Val(lblQuesRemain.Text) <= 0 Then
            timerTimer.Stop()
            If varQuesAnsweredTotal = 0 Then
                lblScorePercent.Text = "0%"
            End If
            MsgBox("The quiz is over! Good game!" & vbCrLf & vbCrLf & "Well done - you finished all the questions in time! You got " & lblScorePercent.Text & "! ")
            funcInitialize()
        ElseIf btnAnswerB.Text = varQuesAnswer Then
            varQuesAnsweredCorrect = varQuesAnsweredCorrect + 1
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
            End Select
            lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
        Else
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
                    lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
            End Select
        End If
    End Sub

    Private Sub btnAnswerC_Click(sender As Object, e As EventArgs) Handles btnAnswerC.Click
        If Val(lblQuesRemain.Text) <= 0 Then
            timerTimer.Stop()
            If varQuesAnsweredTotal = 0 Then
                lblScorePercent.Text = "0%"
            End If
            MsgBox("The quiz is over! Good game!" & vbCrLf & vbCrLf & "Well done - you finished all the questions in time! You got " & lblScorePercent.Text & "! ")
            funcInitialize()
        ElseIf btnAnswerC.Text = varQuesAnswer Then
            varQuesAnsweredCorrect = varQuesAnsweredCorrect + 1
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
            End Select
            lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
        Else
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
            End Select
            lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
        End If
    End Sub

    Private Sub btnAnswerD_Click(sender As Object, e As EventArgs) Handles btnAnswerD.Click
        If Val(lblQuesRemain.Text) <= 0 Then
            timerTimer.Stop()
            If varQuesAnsweredTotal = 0 Then
                lblScorePercent.Text = "0%"
            End If
            MsgBox("The quiz is over! Good game!" & vbCrLf & vbCrLf & "Well done - you finished all the questions in time! You got " & lblScorePercent.Text & "! ")
            funcInitialize()
        ElseIf btnAnswerD.Text = varQuesAnswer Then
            varQuesAnsweredCorrect = varQuesAnsweredCorrect + 1
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
            End Select
            lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
        Else
            varQuesAnsweredTotal = varQuesAnsweredTotal + 1
            lblScorePercent.Text = Val(Math.Round(((varQuesAnsweredCorrect / varQuesAnsweredTotal) * 100), 1)) & "%"
            Select Case varQuizType
                Case 1
                    funcQuesGeneratorAdd()
                Case 2
                    funcQuesGeneratorSub()
                Case 3
                    funcQuesGeneratorMul()
                Case 4
                    funcQuesGeneratorDiv()
                Case 5
                    funcQuesGeneratorRnd()
            End Select
            lblQuesRemain.Text = Val(lblQuesRemain.Text) - 1
        End If
    End Sub
End Class
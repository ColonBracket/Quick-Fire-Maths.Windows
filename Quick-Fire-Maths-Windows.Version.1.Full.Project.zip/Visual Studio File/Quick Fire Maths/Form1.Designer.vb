﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblQuesNumber1 = New System.Windows.Forms.Label()
        Me.lblQuizTypeSymbol = New System.Windows.Forms.Label()
        Me.btnAnswerA = New System.Windows.Forms.Button()
        Me.btnAnswerD = New System.Windows.Forms.Button()
        Me.btnAnswerB = New System.Windows.Forms.Button()
        Me.btnAnswerC = New System.Windows.Forms.Button()
        Me.lblQuesNumber2 = New System.Windows.Forms.Label()
        Me.lblScore = New System.Windows.Forms.Label()
        Me.lblTimerLabel = New System.Windows.Forms.Label()
        Me.lblScorePercent = New System.Windows.Forms.Label()
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.btnQuizTypeRnd = New System.Windows.Forms.Button()
        Me.btnQuizTypeAdd = New System.Windows.Forms.Button()
        Me.btnQuizTypeSub = New System.Windows.Forms.Button()
        Me.btnQuizTypeMul = New System.Windows.Forms.Button()
        Me.btnQuizTypeDiv = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.lblQuesRemain = New System.Windows.Forms.Label()
        Me.lblQuesRemainLabel = New System.Windows.Forms.Label()
        Me.timerTimer = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'lblQuesNumber1
        '
        Me.lblQuesNumber1.Font = New System.Drawing.Font("Arial", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuesNumber1.ForeColor = System.Drawing.Color.White
        Me.lblQuesNumber1.Location = New System.Drawing.Point(146, 163)
        Me.lblQuesNumber1.Name = "lblQuesNumber1"
        Me.lblQuesNumber1.Size = New System.Drawing.Size(180, 120)
        Me.lblQuesNumber1.TabIndex = 2
        Me.lblQuesNumber1.Text = "0"
        Me.lblQuesNumber1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblQuizTypeSymbol
        '
        Me.lblQuizTypeSymbol.AutoSize = True
        Me.lblQuizTypeSymbol.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuizTypeSymbol.ForeColor = System.Drawing.Color.White
        Me.lblQuizTypeSymbol.Location = New System.Drawing.Point(387, 198)
        Me.lblQuizTypeSymbol.Name = "lblQuizTypeSymbol"
        Me.lblQuizTypeSymbol.Size = New System.Drawing.Size(55, 72)
        Me.lblQuizTypeSymbol.TabIndex = 4
        Me.lblQuizTypeSymbol.Text = "*"
        Me.lblQuizTypeSymbol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnAnswerA
        '
        Me.btnAnswerA.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAnswerA.Location = New System.Drawing.Point(12, 353)
        Me.btnAnswerA.Name = "btnAnswerA"
        Me.btnAnswerA.Size = New System.Drawing.Size(160, 40)
        Me.btnAnswerA.TabIndex = 5
        Me.btnAnswerA.Text = "A"
        Me.btnAnswerA.UseVisualStyleBackColor = True
        '
        'btnAnswerD
        '
        Me.btnAnswerD.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAnswerD.Location = New System.Drawing.Point(518, 353)
        Me.btnAnswerD.Name = "btnAnswerD"
        Me.btnAnswerD.Size = New System.Drawing.Size(160, 40)
        Me.btnAnswerD.TabIndex = 7
        Me.btnAnswerD.Text = "D"
        Me.btnAnswerD.UseVisualStyleBackColor = True
        '
        'btnAnswerB
        '
        Me.btnAnswerB.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAnswerB.Location = New System.Drawing.Point(181, 353)
        Me.btnAnswerB.Name = "btnAnswerB"
        Me.btnAnswerB.Size = New System.Drawing.Size(160, 40)
        Me.btnAnswerB.TabIndex = 8
        Me.btnAnswerB.Text = "B"
        Me.btnAnswerB.UseVisualStyleBackColor = True
        '
        'btnAnswerC
        '
        Me.btnAnswerC.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAnswerC.Location = New System.Drawing.Point(349, 353)
        Me.btnAnswerC.Name = "btnAnswerC"
        Me.btnAnswerC.Size = New System.Drawing.Size(160, 40)
        Me.btnAnswerC.TabIndex = 9
        Me.btnAnswerC.Text = "C"
        Me.btnAnswerC.UseVisualStyleBackColor = True
        '
        'lblQuesNumber2
        '
        Me.lblQuesNumber2.Font = New System.Drawing.Font("Arial", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuesNumber2.ForeColor = System.Drawing.Color.White
        Me.lblQuesNumber2.Location = New System.Drawing.Point(498, 163)
        Me.lblQuesNumber2.Name = "lblQuesNumber2"
        Me.lblQuesNumber2.Size = New System.Drawing.Size(180, 120)
        Me.lblQuesNumber2.TabIndex = 10
        Me.lblQuesNumber2.Text = "0"
        Me.lblQuesNumber2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblScore
        '
        Me.lblScore.AutoSize = True
        Me.lblScore.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScore.ForeColor = System.Drawing.Color.White
        Me.lblScore.Location = New System.Drawing.Point(12, 141)
        Me.lblScore.Name = "lblScore"
        Me.lblScore.Size = New System.Drawing.Size(106, 37)
        Me.lblScore.TabIndex = 11
        Me.lblScore.Text = "Score"
        Me.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimerLabel
        '
        Me.lblTimerLabel.AutoSize = True
        Me.lblTimerLabel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimerLabel.ForeColor = System.Drawing.Color.White
        Me.lblTimerLabel.Location = New System.Drawing.Point(12, 226)
        Me.lblTimerLabel.Name = "lblTimerLabel"
        Me.lblTimerLabel.Size = New System.Drawing.Size(105, 37)
        Me.lblTimerLabel.TabIndex = 12
        Me.lblTimerLabel.Text = "Timer"
        Me.lblTimerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblScorePercent
        '
        Me.lblScorePercent.AutoSize = True
        Me.lblScorePercent.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblScorePercent.ForeColor = System.Drawing.Color.White
        Me.lblScorePercent.Location = New System.Drawing.Point(13, 178)
        Me.lblScorePercent.Name = "lblScorePercent"
        Me.lblScorePercent.Size = New System.Drawing.Size(97, 36)
        Me.lblScorePercent.TabIndex = 13
        Me.lblScorePercent.Text = "100%"
        Me.lblScorePercent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTimer
        '
        Me.lblTimer.AutoSize = True
        Me.lblTimer.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimer.ForeColor = System.Drawing.Color.White
        Me.lblTimer.Location = New System.Drawing.Point(13, 263)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(51, 36)
        Me.lblTimer.TabIndex = 14
        Me.lblTimer.Text = "30"
        Me.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnQuizTypeRnd
        '
        Me.btnQuizTypeRnd.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuizTypeRnd.Location = New System.Drawing.Point(548, 12)
        Me.btnQuizTypeRnd.Name = "btnQuizTypeRnd"
        Me.btnQuizTypeRnd.Size = New System.Drawing.Size(130, 40)
        Me.btnQuizTypeRnd.TabIndex = 19
        Me.btnQuizTypeRnd.Text = "Random"
        Me.btnQuizTypeRnd.UseVisualStyleBackColor = True
        '
        'btnQuizTypeAdd
        '
        Me.btnQuizTypeAdd.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuizTypeAdd.Location = New System.Drawing.Point(12, 12)
        Me.btnQuizTypeAdd.Name = "btnQuizTypeAdd"
        Me.btnQuizTypeAdd.Size = New System.Drawing.Size(130, 40)
        Me.btnQuizTypeAdd.TabIndex = 20
        Me.btnQuizTypeAdd.Text = "+"
        Me.btnQuizTypeAdd.UseVisualStyleBackColor = True
        '
        'btnQuizTypeSub
        '
        Me.btnQuizTypeSub.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuizTypeSub.Location = New System.Drawing.Point(146, 12)
        Me.btnQuizTypeSub.Name = "btnQuizTypeSub"
        Me.btnQuizTypeSub.Size = New System.Drawing.Size(130, 40)
        Me.btnQuizTypeSub.TabIndex = 21
        Me.btnQuizTypeSub.Text = "-"
        Me.btnQuizTypeSub.UseVisualStyleBackColor = True
        '
        'btnQuizTypeMul
        '
        Me.btnQuizTypeMul.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuizTypeMul.Location = New System.Drawing.Point(280, 12)
        Me.btnQuizTypeMul.Name = "btnQuizTypeMul"
        Me.btnQuizTypeMul.Size = New System.Drawing.Size(130, 40)
        Me.btnQuizTypeMul.TabIndex = 22
        Me.btnQuizTypeMul.Text = "*"
        Me.btnQuizTypeMul.UseVisualStyleBackColor = True
        '
        'btnQuizTypeDiv
        '
        Me.btnQuizTypeDiv.Font = New System.Drawing.Font("Arial", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuizTypeDiv.Location = New System.Drawing.Point(414, 12)
        Me.btnQuizTypeDiv.Name = "btnQuizTypeDiv"
        Me.btnQuizTypeDiv.Size = New System.Drawing.Size(130, 40)
        Me.btnQuizTypeDiv.TabIndex = 23
        Me.btnQuizTypeDiv.Text = "/"
        Me.btnQuizTypeDiv.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(12, 58)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(130, 40)
        Me.btnHelp.TabIndex = 24
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'lblQuesRemain
        '
        Me.lblQuesRemain.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblQuesRemain.AutoSize = True
        Me.lblQuesRemain.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuesRemain.ForeColor = System.Drawing.Color.White
        Me.lblQuesRemain.Location = New System.Drawing.Point(507, 92)
        Me.lblQuesRemain.Name = "lblQuesRemain"
        Me.lblQuesRemain.Size = New System.Drawing.Size(51, 36)
        Me.lblQuesRemain.TabIndex = 26
        Me.lblQuesRemain.Text = "25"
        Me.lblQuesRemain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblQuesRemainLabel
        '
        Me.lblQuesRemainLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblQuesRemainLabel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuesRemainLabel.ForeColor = System.Drawing.Color.White
        Me.lblQuesRemainLabel.Location = New System.Drawing.Point(353, 58)
        Me.lblQuesRemainLabel.Name = "lblQuesRemainLabel"
        Me.lblQuesRemainLabel.Size = New System.Drawing.Size(325, 44)
        Me.lblQuesRemainLabel.TabIndex = 25
        Me.lblQuesRemainLabel.Text = "Questions Remaining"
        Me.lblQuesRemainLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'timerTimer
        '
        Me.timerTimer.Enabled = True
        Me.timerTimer.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(119, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(690, 405)
        Me.Controls.Add(Me.lblQuesRemain)
        Me.Controls.Add(Me.lblQuesRemainLabel)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnQuizTypeDiv)
        Me.Controls.Add(Me.btnQuizTypeMul)
        Me.Controls.Add(Me.btnQuizTypeSub)
        Me.Controls.Add(Me.btnQuizTypeAdd)
        Me.Controls.Add(Me.btnQuizTypeRnd)
        Me.Controls.Add(Me.lblTimer)
        Me.Controls.Add(Me.lblScorePercent)
        Me.Controls.Add(Me.lblTimerLabel)
        Me.Controls.Add(Me.lblScore)
        Me.Controls.Add(Me.lblQuesNumber2)
        Me.Controls.Add(Me.btnAnswerC)
        Me.Controls.Add(Me.btnAnswerB)
        Me.Controls.Add(Me.btnAnswerD)
        Me.Controls.Add(Me.btnAnswerA)
        Me.Controls.Add(Me.lblQuizTypeSymbol)
        Me.Controls.Add(Me.lblQuesNumber1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Quick Fire Maths"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblQuesNumber1 As Label
    Friend WithEvents lblQuizTypeSymbol As Label
    Friend WithEvents btnAnswerA As Button
    Friend WithEvents btnAnswerD As Button
    Friend WithEvents btnAnswerB As Button
    Friend WithEvents btnAnswerC As Button
    Friend WithEvents lblQuesNumber2 As Label
    Friend WithEvents lblScore As Label
    Friend WithEvents lblTimerLabel As Label
    Friend WithEvents lblScorePercent As Label
    Friend WithEvents lblTimer As Label
    Friend WithEvents btnQuizTypeRnd As Button
    Friend WithEvents btnQuizTypeAdd As Button
    Friend WithEvents btnQuizTypeSub As Button
    Friend WithEvents btnQuizTypeMul As Button
    Friend WithEvents btnQuizTypeDiv As Button
    Friend WithEvents btnHelp As Button
    Friend WithEvents lblQuesRemain As Label
    Friend WithEvents lblQuesRemainLabel As Label
    Friend WithEvents timerTimer As Timer
End Class
